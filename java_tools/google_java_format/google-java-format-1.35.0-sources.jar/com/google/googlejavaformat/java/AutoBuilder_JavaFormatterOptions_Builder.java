package com.google.googlejavaformat.java;

import javax.annotation.processing.Generated;

@Generated("com.google.auto.value.processor.AutoBuilderProcessor")
class AutoBuilder_JavaFormatterOptions_Builder extends JavaFormatterOptions.Builder {

  private Boolean formatJavadoc;

  private Boolean reorderModifiers;

  private JavaFormatterOptions.Style style;

  AutoBuilder_JavaFormatterOptions_Builder() {
  }

  @Override
  public JavaFormatterOptions.Builder formatJavadoc(boolean formatJavadoc) {
    this.formatJavadoc = formatJavadoc;
    return this;
  }

  @Override
  public JavaFormatterOptions.Builder reorderModifiers(boolean reorderModifiers) {
    this.reorderModifiers = reorderModifiers;
    return this;
  }

  @Override
  public JavaFormatterOptions.Builder style(JavaFormatterOptions.Style style) {
    if (style == null) {
      throw new NullPointerException("Null style");
    }
    this.style = style;
    return this;
  }

  @Override
  public JavaFormatterOptions build() {
    if (this.formatJavadoc == null
        || this.reorderModifiers == null
        || this.style == null) {
      StringBuilder missing = new StringBuilder();
      if (this.formatJavadoc == null) {
        missing.append(" formatJavadoc");
      }
      if (this.reorderModifiers == null) {
        missing.append(" reorderModifiers");
      }
      if (this.style == null) {
        missing.append(" style");
      }
      throw new IllegalStateException("Missing required properties:" + missing);
    }
    return new JavaFormatterOptions(
        this.formatJavadoc,
        this.reorderModifiers,
        this.style);
  }
}
